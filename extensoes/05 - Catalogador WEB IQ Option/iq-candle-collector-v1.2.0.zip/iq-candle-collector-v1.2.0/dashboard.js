const $ = (id) => document.getElementById(id);
let allCandles = [];
let refreshTimer = null;

async function send(type, extra = {}) {
  return chrome.runtime.sendMessage({ type, ...extra });
}

function formatTf(value) {
  const n = Number(value);
  if (!n) return "—";
  if (n < 60) return `${n}s`;
  if (n % 2592000 === 0) return `${n / 2592000}M`;
  if (n % 604800 === 0) return `${n / 604800}W`;
  if (n % 86400 === 0) return `${n / 86400}D`;
  if (n % 3600 === 0) return `${n / 3600}H`;
  return `M${n / 60}`;
}

function formatNumber(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "—";
  const abs = Math.abs(n);
  const digits = abs >= 100 ? 3 : abs >= 1 ? 5 : 7;
  return n.toLocaleString("pt-BR", { maximumFractionDigits: digits });
}

function formatDate(seconds) {
  return new Date(Number(seconds) * 1000).toLocaleString("pt-BR");
}
function formatIso(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString("pt-BR");
}
function formatLatency(ms) {
  const n = Number(ms);
  if (!Number.isFinite(n)) return "—";
  return n < 1000 ? `${Math.round(n)} ms` : `${(n / 1000).toFixed(2).replace(".", ",")} s`;
}

function setOptions(select, values, formatter = x => x) {
  const current = select.value;
  const first = select.options[0].outerHTML;
  select.innerHTML = first + values.map(v =>
    `<option value="${String(v).replaceAll('"', '&quot;')}">${formatter(v)}</option>`
  ).join("");
  if ([...select.options].some(o => o.value === current)) select.value = current;
}

function filteredCandles() {
  const asset = $("assetFilter").value;
  const timeframe = $("timeframeFilter").value;
  const status = $("statusFilter").value;
  const limit = Number($("limitFilter").value || 300);

  return allCandles
    .filter(c => !asset || c.asset === asset)
    .filter(c => !timeframe || String(c.timeframe) === timeframe)
    .filter(c => {
      if (status === "closed") return c.closed;
      if (status === "open") return !c.closed;
      if (status === "pending") return c.closed && !c.synced;
      if (status === "synced") return c.synced;
      return true;
    })
    .sort((a, b) => b.from - a.from)
    .slice(0, limit);
}

function updateMetrics(rows) {
  const call = rows.filter(c => c.direction === "CALL").length;
  const put = rows.filter(c => c.direction === "PUT").length;
  const doji = rows.filter(c => c.direction === "DOJI").length;
  $("metricTotal").textContent = rows.length;
  $("metricClosed").textContent = rows.filter(c => c.closed).length;
  $("metricOpen").textContent = rows.filter(c => !c.closed).length;
  $("metricPending").textContent = rows.filter(c => c.closed && !c.synced).length;
  $("metricDirections").textContent = `${call} / ${put} / ${doji}`;
  const latencies = rows.map(c => Number(c.captureLatencyMs)).filter(Number.isFinite);
  const avgLatency = latencies.length ? latencies.reduce((a,b) => a+b, 0) / latencies.length : null;
  $("metricLatency").textContent = avgLatency == null ? "—" : formatLatency(avgLatency);
}

function renderTable(rows) {
  const tbody = $("candleRows");
  $("tableCount").textContent = `${rows.length} registro(s)`;
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="15" class="empty">Nenhuma vela encontrada para os filtros selecionados.</td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map(c => `
    <tr>
      <td>${formatDate(c.from)}</td>
      <td>${formatDate(c.to)}</td>
      <td>${formatIso(c.capturedAt)}</td>
      <td>${formatLatency(c.captureLatencyMs)}</td>
      <td>${c.asset}</td>
      <td>${formatTf(c.timeframe)}</td>
      <td>${formatNumber(c.open)}</td>
      <td>${formatNumber(c.high)}</td>
      <td>${formatNumber(c.low)}</td>
      <td>${formatNumber(c.close)}</td>
      <td>${formatNumber(c.body)}</td>
      <td>${formatNumber(c.range)}</td>
      <td><span class="badge ${String(c.direction).toLowerCase()}">${c.direction}</span></td>
      <td><span class="badge neutral">${c.closed ? "Fechada" : "Formação"}</span></td>
      <td><span class="badge neutral">${c.synced ? "Enviada" : "Pendente"}</span></td>
    </tr>
  `).join("");
}

function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function drawChart(rows) {
  const canvas = $("candleChart");
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const displayWidth = Math.max(canvas.parentElement.clientWidth, 780);
  const height = 430;
  canvas.style.width = `${displayWidth}px`;
  canvas.style.height = `${height}px`;
  canvas.width = Math.floor(displayWidth * dpr);
  canvas.height = Math.floor(height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  ctx.clearRect(0, 0, displayWidth, height);

  const chartRows = [...rows].reverse().slice(-120);
  $("chartCount").textContent = `${chartRows.length} vela(s)`;
  const asset = $("assetFilter").value || "todos os ativos";
  const tf = $("timeframeFilter").value ? formatTf($("timeframeFilter").value) : "todos os períodos";
  $("chartSubtitle").textContent = `${asset} • ${tf} • até 120 velas no gráfico`;

  if (!chartRows.length) {
    ctx.fillStyle = cssVar("--muted");
    ctx.font = "14px Arial";
    ctx.textAlign = "center";
    ctx.fillText("Sem dados para desenhar o gráfico.", displayWidth / 2, height / 2);
    return;
  }

  const pad = { left: 70, right: 20, top: 20, bottom: 42 };
  const plotW = displayWidth - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;
  const min = Math.min(...chartRows.map(c => Number(c.low)));
  const max = Math.max(...chartRows.map(c => Number(c.high)));
  const range = max - min || 1;
  const y = price => pad.top + ((max - price) / range) * plotH;

  ctx.strokeStyle = cssVar("--border");
  ctx.fillStyle = cssVar("--muted");
  ctx.lineWidth = 1;
  ctx.font = "12px Arial";
  ctx.textAlign = "right";
  for (let i = 0; i <= 5; i++) {
    const py = pad.top + (plotH / 5) * i;
    const price = max - (range / 5) * i;
    ctx.beginPath();
    ctx.moveTo(pad.left, py);
    ctx.lineTo(displayWidth - pad.right, py);
    ctx.stroke();
    ctx.fillText(formatNumber(price), pad.left - 8, py + 4);
  }

  const slot = plotW / chartRows.length;
  const bodyW = Math.max(2, Math.min(12, slot * 0.62));

  chartRows.forEach((c, i) => {
    const x = pad.left + slot * i + slot / 2;
    const color = c.direction === "CALL" ? cssVar("--call") :
                  c.direction === "PUT" ? cssVar("--put") : cssVar("--doji");
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x, y(c.high));
    ctx.lineTo(x, y(c.low));
    ctx.stroke();

    const yo = y(c.open);
    const yc = y(c.close);
    const top = Math.min(yo, yc);
    const bodyH = Math.max(2, Math.abs(yc - yo));
    if (c.direction === "DOJI") {
      ctx.fillRect(x - bodyW / 2, top - 1, bodyW, 2);
    } else {
      ctx.fillRect(x - bodyW / 2, top, bodyW, bodyH);
    }
  });

  const labelStep = Math.max(1, Math.ceil(chartRows.length / 7));
  ctx.fillStyle = cssVar("--muted");
  ctx.textAlign = "center";
  chartRows.forEach((c, i) => {
    if (i % labelStep !== 0 && i !== chartRows.length - 1) return;
    const x = pad.left + slot * i + slot / 2;
    const d = new Date(c.from * 1000);
    const label = d.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    ctx.save();
    ctx.translate(x, height - 12);
    ctx.rotate(-0.35);
    ctx.fillText(label, 0, 0);
    ctx.restore();
  });
}

function render() {
  const rows = filteredCandles();
  updateMetrics(rows);
  renderTable(rows);
  drawChart(rows);
}

async function loadData(showMessage = false) {
  try {
    const [data, status] = await Promise.all([
      send("GET_CANDLES"),
      send("GET_STATUS")
    ]);
    allCandles = data.candles || [];

    const assets = [...new Set(allCandles.map(c => c.asset))].sort();
    const timeframes = [...new Set(allCandles.map(c => Number(c.timeframe)))].sort((a,b) => a-b);
    setOptions($("assetFilter"), assets);
    setOptions($("timeframeFilter"), timeframes, formatTf);

    $("captureStatus").textContent = status.enabled ? "Capturando" : "Pausado";
    $("liveDot").classList.toggle("active", Boolean(status.enabled));
    render();
    if (showMessage) $("message").textContent = `Atualizado às ${new Date().toLocaleTimeString("pt-BR")}.`;
  } catch (error) {
    $("message").textContent = `Erro ao carregar dados: ${error.message}`;
  }
}

function configureTimer() {
  if (refreshTimer) clearInterval(refreshTimer);
  const seconds = Number($("refreshFilter").value);
  if (seconds > 0) refreshTimer = setInterval(() => loadData(false), seconds * 1000);
}

function exportFiltered() {
  const rows = filteredCandles();
  const blob = new Blob([JSON.stringify(rows, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `iq-candles-filtradas-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

["assetFilter", "timeframeFilter", "statusFilter", "limitFilter"].forEach(id => {
  $(id).addEventListener("change", render);
});
$("refreshFilter").addEventListener("change", configureTimer);
$("refreshBtn").addEventListener("click", () => loadData(true));
$("exportFilteredBtn").addEventListener("click", exportFiltered);
window.addEventListener("resize", () => drawChart(filteredCandles()));

loadData(true);
configureTimer();
