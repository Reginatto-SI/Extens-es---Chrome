# IQ Candle Collector v1.2.0

Extensão Chrome Manifest V3 para capturar candles recebidos pela página da IQ Option, armazená-los localmente, visualizá-los e sincronizá-los com uma API.

## Novidades da versão 1.1

- Página completa de visualização.
- Gráfico de candles sem bibliotecas externas.
- Tabela com OHLC, corpo, amplitude, direção, estado e sincronização.
- Filtros por ativo, timeframe e situação.
- Seleção das últimas 50, 100, 300 ou 1.000 velas.
- Atualização automática configurável.
- Exportação apenas das velas filtradas.
- Métricas de CALL, PUT, DOJI, fechadas, em formação e pendentes.

## Instalação

1. Extraia o ZIP.
2. Abra `chrome://extensions`.
3. Ative **Modo do desenvolvedor**.
4. Remova ou desative a versão anterior para evitar dois coletores simultâneos.
5. Clique em **Carregar sem compactação**.
6. Selecione a pasta `iq-candle-collector-v1.2.0`.
7. Abra ou recarregue a página da IQ Option.
8. Abra o popup e clique em **Visualizar velas**.

## Atualização sobre a versão anterior

O banco IndexedDB pertence ao ID da extensão. Ao carregar esta versão como uma nova pasta, o Chrome pode gerar outro ID e, nesse caso, os dados locais da instalação anterior não aparecem automaticamente. Para preservar o mesmo banco durante desenvolvimento, substitua os arquivos na pasta antiga e clique em **Atualizar** em `chrome://extensions`.

## API

Configure a URL base no popup. O envio é feito para:

`POST {URL_BASE}/api/candles`

Payload:

```json
{
  "device": "chrome-extension",
  "version": "1.0.0",
  "candles": []
}
```

## Limitações

- A extensão captura o histórico que a própria página solicita.
- O gráfico exibe até 120 velas por vez para manter a leitura clara.
- Alterações internas na plataforma podem exigir atualização do parser.
- A ferramenta não executa operações nem automatiza ordens.


## Correção da versão 1.1.1

- Corrigido o botão **Visualizar velas**, que agora abre `dashboard.html` em uma nova aba.


## Novidades da versão 1.2.0

- Horário oficial de início da vela (`from`).
- Horário oficial de fechamento da vela (`to`).
- Horário em que a mensagem chegou ao navegador (`capturedAt`).
- Horário de preparação para gravação local (`storedAt`).
- Timestamp bruto do servidor (`server_timestamp`).
- Latência aproximada exibida por vela e em média no painel.

A latência é mais útil para velas em tempo real. Para candles históricos, ela pode ser alta porque o histórico é solicitado e recebido depois que as velas já fecharam.
